#ifndef MAPREDUCE_H
#define MAPREDUCE_H

#include "utils.h" //sendChunkData and shuffle

void execute(char **argv, int nProcesses);

#endif